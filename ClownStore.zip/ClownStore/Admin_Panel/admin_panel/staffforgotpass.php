<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <script src="./admin_assets/js/login.js" type="text/javascript"></script>
   <link rel="stylesheet" href="./admin_assets/css/staffforgotpass.css"/>
   <style>
       body{
    background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url(../images/animebackground3.jpeg);
    background-size: cover;
}
.formtable{
margin: 10% 20% 20% 30%;
border: solid rgb(249, 201, 201) ;
position: absolute;
width: 600px;
height: 450px;
font-size: 1.5em;
}
.title{
    text-align: center;
    text-decoration: none;
    text-align: center;
    font-size: 60px;
    font-family: fantasy;
    color: rgb(253, 242, 242);
    text-shadow: 1px 2px 10px rgb(24, 13, 13);
}
.formforgot{
    position: relative;
    margin-top: 10%;
    margin-left: 15%;
}
.back{
    font-size: larger;
    color: rgb(230, 225, 192);
    background-color: rgba(2, 4, 23,0.2);
    cursor: pointer;
}
.back:hover{
    color: rgba(230,225,192,0.8);
}
.info{
    width: 80%;
    height: 30px;
    border-radius: 1em;
    background-color: rgba(247, 211, 184, 0.5);
    color: white;
    font-size: 0.8em;
}
.info:hover{
    background-color: rgba(247, 211, 184, 0.7);
}
.submit{
    /*margin-left:25%;*/
    font-size: 0.8em;
    margin-top: 5%;
    cursor: pointer;
    height: 30%;
    border-radius: 1em;
    background-color: rgba(251, 191, 145, 0.8);
    margin-bottom: 2%;
}
.submit:hover{
    background-color: rgb(189, 244, 246);
}
   </style>
</head>
<body>
    <div class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Forgot Password</h1>
    <form method="get" class="formforgot" action="../../resetpassword.php">
        <table style="line-height: 39px;" class="form">
        <tr><td><label style="color: white;" for="email">Email:</label></td>
        <td><input class="info" style="width: 95%" type="email" required id="email" name="email"></td>
        <!--<tr><td><label style="color: white;" for="favcolor">Favourite Colour:</label></td>
        <td><input class="info" type="text" required id="favcolor" name="favcolor"></td><br></tr>
        <tr><td><label style="color: white;" for="primschool">Primary School:</label></td>
        <td><input class="info" type="primschool" required id="primschool" name="primschool"></td>-->
        <td><button onclick="sendemail()" class="submit">Send</button></td></tr>
    </table>
    </form>   
</div>
</body>
</html>
<script>
    function sendemail(){
        alert("A reset password link had sent to your email. Please check it now")
    }
    </script>