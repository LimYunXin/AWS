<?php
 $conn = new mysqli('localhost', 'root', '', 'assignment');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all members from database
$sql = "SELECT * FROM member ORDER BY MemberID DESC";
$result = $conn->query($sql);

// Handle member deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM member WHERE MemberID = ?");
    $stmt->bind_param("i", $delete_id);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Member deleted successfully";
        header("Location: viewCustomers.php");
        exit();
    } else {
        $_SESSION['error'] = "Error deleting member";
    }
}

// Handle bulk actions
if (isset($_POST['bulk_action'])) {
    if (!empty($_POST['selected_members'])) {
        $member_ids = implode(",", $_POST['selected_members']);
        
        switch ($_POST['bulk_action']) {
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM member WHERE MemberID IN ($member_ids)");
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Selected members deleted successfully";
                } else {
                    $_SESSION['error'] = "Error deleting members";
                }
                break;
        }
        
        header("Location: viewCustomers.php");
        exit();
    } else {
        $_SESSION['error'] = "No members selected";
        header("Location: viewCustomers.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - View Members</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --admin-primary: #4e73df;
            --admin-secondary: #1cc88a;
            --admin-danger: #e74a3b;
            --admin-warning: #f6c23e;
        }
        
        body {
            background-color: #f8f9fc;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--admin-primary) 10%, #224abe 100%);
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            background-color: #f8f9fc;
            border-bottom: 1px solid #e3e6f0;
            font-weight: 600;
        }
        
        .btn-action {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .search-box {
            max-width: 300px;
        }
        
        .bulk-actions {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar bg-dark">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="dashboard.php">
                                <i class="fas fa-fw fa-tachometer-alt mr-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="viewProduct.php">
                                <i class="fas fa-fw fa-boxes mr-2"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="viewCustomers.php">
                                <i class="fas fa-fw fa-users mr-2"></i> Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="viewStaffInfo.php">
                                <i class="fas fa-fw fa-user-tie me-2"></i> Staff
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="/AnimeSociety/Participant/pages/logout.php">
                                <i class="fas fa-fw fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Member Management</h1>
                </div>

                <!-- Messages -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['message']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['error']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-users mr-2"></i>All Members</span>
                    </div>
                    <div class="card-body">
                        <form method="post" action="viewCustomers.php">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover" width="100%" cellspacing="0">
                                    <thead class="thead-light">
                                        <tr>
                                            <th width="5%">#</th>
                                            <th>Member ID</th>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>Contact Number</th>
                                            <th>Gender</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($result && $result->num_rows > 0): ?>
                                            <?php $rowNumber = 1; ?>
                                            <?php while ($member = $result->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo $rowNumber++; ?></td>
                                                    <td><?php echo htmlspecialchars($member['MemberID']); ?></td>
                                                    <td><?php echo htmlspecialchars($member['Name']); ?></td>
                                                    <td><?php echo htmlspecialchars($member['Email']); ?></td>
                                                    <td><?php echo htmlspecialchars($member['Phoneno']); ?></td>
                                                    <td><?php echo htmlspecialchars($member['Gender']); ?></td>
                                                </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No members found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>