<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Staff Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --admin-primary: #4e73df;
            --admin-secondary: #1cc88a;
            --admin-danger: #e74a3b;
        }
        
        body {
            background-color: #f8f9fc;
        }
        
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            background-color: #f8f9fc;
            border-bottom: 1px solid #e3e6f0;
            font-weight: 600;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--admin-primary) 10%, #224abe 100%);
            min-height: 100vh;
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
            border-radius: 4px;
        }
        
        .staff-image {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid #fff;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .staff-info-label {
            font-weight: 600;
            color: #4e73df;
        }
        
        .staff-info-value {
            font-size: 1.1rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar bg-dark">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="dashboard.php">
                                <i class="fas fa-fw fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="viewProduct.php">
                                <i class="fas fa-fw fa-boxes me-2"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="viewCustomers.php">
                                <i class="fas fa-fw fa-users me-2"></i> Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="viewStaffInfo.php">
                                <i class="fas fa-fw fa-user-tie me-2"></i> Staff
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="admin_logout.php">
                                <i class="fas fa-fw fa-sign-out-alt me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Staff Information</h1>
                    
                </div>

                <?php
                include("../database.php");
                  
                $sql = "SELECT * FROM staff";
                          
                // Execute SQL query
                $result = $conn->query($sql);
                if($row = $result->fetch_object())
                {
                    // Read records from each field
                    $fname = $row->first_name;
                    $lname = $row->last_name;
                    $gender = $row->gender;
                    $email = $row->email;
                    $phone = $row->phone;
                    $position = $row->position;
                    $birth = $row->birthday;
                    $country = $row->country;
                    $img = $row->img_path;
                    $id = $row->staff_id;
                }
                else
                {
                    // No record selected
                    echo '
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i> Database error. Record Not Found.
                        </div>
                        ';
                }
                $result->free();
                ?>

                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-user-circle me-2"></i>Personal Details
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <!-- Staff Image -->
                            <div class="col-md-3 text-center mb-4">
                                <img src="admin_assets/images/<?php echo $img ?>" alt="Staff Photo" class="staff-image mb-3">
                                <h5 class="mb-1"><?php echo $fname . ' ' . $lname ?></h5>
                                <span class="badge bg-primary"><?php echo $position ?></span>
                            </div>
                            
                            <!-- Staff Information -->
                            <div class="col-md-9">
                                <div class="row g-3">
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">First Name</div>
                                        <div class="staff-info-value"><?php echo $fname ?></div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">Last Name</div>
                                        <div class="staff-info-value"><?php echo $lname ?></div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">Gender</div>
                                        <div class="staff-info-value">
                                            <?php if($gender == 'M'): ?>
                                                <i class="fas fa-mars text-primary me-1"></i> Male
                                            <?php elseif($gender == 'F'): ?>
                                                <i class="fas fa-venus text-danger me-1"></i> Female
                                            <?php else: ?>
                                                <?php echo $gender ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">Birthday</div>
                                        <div class="staff-info-value">
                                            <i class="fas fa-birthday-cake me-1"></i>
                                            <?php echo date('F j, Y', strtotime($birth)) ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">Email</div>
                                        <div class="staff-info-value">
                                            <i class="fas fa-envelope me-1"></i>
                                            <?php echo $email ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">Phone</div>
                                        <div class="staff-info-value">
                                            <i class="fas fa-phone me-1"></i>
                                            <?php echo $phone ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">Position</div>
                                        <div class="staff-info-value">
                                            <i class="fas fa-briefcase me-1"></i>
                                            <?php echo $position ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <div class="staff-info-label">Country</div>
                                        <div class="staff-info-value">
                                            <i class="fas fa-globe me-1"></i>
                                            <?php echo $country ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="d-flex justify-content-end">
                            <a href="editStaff.php?id=<?php echo $id ?>" class="btn btn-primary">
                                <i class="fas fa-edit me-2"></i> Edit Information
                            </a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>