<!-- Sidebar -->
<div class="sidebar" id="mySidebar">
<div class="side-header">

<?php

  
  $sql = "SELECT * FROM staff";
            
  //excute sql query
  $result = $conn->query($sql);
  
  if($row = $result->fetch_object())
  {
      //read records from the each field
      $name=$row->first_name;
      $img=$row->img_path;
      printf('<img src="./admin_assets/images/%s" width="120" height="120" alt="Admin Icon">',$img);
     printf('<h5 style="margin-top:10px;">Hi, %s</h5>',$name);
  }
  else
  {
      //no record selected
      echo '
          <div class="error">
          Database error. Record Not Found.
          <div>
          ';
  }
  
  $result->free();
 
  
?>
   
</div>

<hr style="border:1px solid; background-color:rgb(205, 133, 63); border-color:#3B3131;">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="./dashboard.php" ><i class="fa fa-th"></i> Dashboard</a>
    <a href="#staffinfo"  onclick="showStaffinfo()" ><i class="fa fa-user"></i> Personal Info</a>
    <a href="#customers"  onclick="showCustomers()" ><i class="fa fa-users"></i> Members</a>
    <a href="#HomePage"   onclick="showHomePage()" ><i class="fa fa-home"></i> Home Page</a>
    <a href="#News"   onclick="showNews()" ><i class="fa fa-bell"></i> News</a>
    <a href="#events"   onclick="showEvents()" ><i class="fa fa-calendar"></i> Events</a>
    <a href="#notes"   onclick="showEventNote()" ><i class="fa fa-edit"></i> Events Note</a>
    <a href="#trailors"   onclick="showTrailor()" ><i class="fa fa-calendar"></i> Trailor</a>
    <a href="#bookings" onclick="showBookings()"><i class="fa fa-book"></i> Booking</a>
    <a href="#feedbacks" onclick="showFeedbacks()"><i class="fa fa-comment"></i>User's Feedbacks</a>
    <a href="#figures" onclick="showFigures()"><i class="fa fa-gift"></i>Figures</a>
  <!---->
</div>
 
<div id="main">
    <button class="openbtn" onclick="openNav()"><i class="fa fa-list"></i></button>
</div>


