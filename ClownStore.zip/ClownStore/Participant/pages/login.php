<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../p_asset/js/login.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../p_asset/css/memberlogin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Member Login</title>
    <style>
        *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    text-transform: capitalize;
    transition: 0.2s linear;
}

html{
    scroll-behavior: smooth;
    scroll-padding-top: 6rem;
    overflow-x: hidden;
}

header{
    font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
    display: flex;
    position: relative;
    top: 0;
    left: 0;
    right: 0;
    background: rgba(255, 255, 255, 0.3);
    padding: 1rem 9%;
    align-items: center;
    justify-content: space-between;
    z-index:1000;
    box-shadow: 0.5rem 1rem rgba(0, 0, 0, 0.1);
}

header .logo{
    font-size: 3rem;
    color: #333;
    font-weight: bolder;
}

header .logo span{
    color: peru;
}

.headertitle{
    font-size: 2rem;
}

header .homehead a{
    font-size: 1.5rem;
    padding: 0 1.5rem;
    color: lightpink;
    
}

header .homehead a:hover{
    color: peru;
}
header .icon {
    padding-top: 2rem;
}

header .icon a{
    font-size: 2rem;
    color: peachpuff;
    margin-left: 1.5rem;
    float: right;
}

header .icon .ccontainer .shopping img{
    max-width: 3.5rem;
    padding: 0;
    margin: 0;
    margin-left: 1rem;
    float: right;
    bottom: 0;
}

header .icon a:hover{
    color: firebrick;
}

.icon{
    display: flex;
}

header #toggler{
    display: none;
}

header .fa-bars{
  font-size:3rem;
  color :#333;
  border-radius: 0.5rem;
  padding: 1.5rem 1.5rem;
  cursor: pointer;
  border: .1rem solid rgba(0, 0, 0, 0.3);  
  display: none;
}



@media (max-width:991px) {
    html{
        font-size: 55%;
    }

    section{
        padding: 2rem;
    } 

    header{
        padding: 2rem;
    }
    
    .home{
        background-position: left;
    }
    
}

@media (max-width:768px){

    header .fa-bars{
        display: block;
    }

    header .homehead{
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: #fff;
        border-top: 0.1rem solid rgba(0, 0, 0, 0.1);
        
    }

    header #toggler:checked ~ .homehead{
        clip-path:polygon(0 0, 100% 0, 100% 0, 0 0);
    }

    header .homehead a{
        margin: 1.5rem;
        padding: 1.5rem;
        background: #fff;
        border: 0.1rem solid rgba(0, 0, 0, 0.1);
        display: block;
    }

    .home .content h3{
        font-size: 5rem;
    }

    .home .content span{
        font-size: 2.5rem;
    }
}

@media (max-width:450px) {
    html{
        font-size: 50%;
    }
    
    .heading{
        font-size: 3rem;
    }
}
body{
    background-image:linear-gradient(to right, rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url(../images/sunset2.jpg)!important;
    background-size: cover;
}
.formtable{
    margin: 30px 50% 30px 25%;
    border: solid rgb(249, 201, 201) ;
    position: absolute;
    width: 600px;
    height: 450px;
    font-size: 1.5em;
    }
    
    .title{
        text-align: center;
        text-decoration: none;
        text-align: center;
        font-size: 60px;
        font-family: fantasy;
        color: rgb(253, 242, 242);
        text-shadow: 1px 2px 10px rgb(24, 13, 13);
    }
    
    .formlogin{
        position: relative;
        margin-left: 15%;
    }
    .submit{
        width: 80%;
    font-size: 0.8em;
    margin-top: 5%;
    cursor: pointer;
    }
    .dhac{
        margin-left: 5%;
    }
    .back{
        font-size: larger;
        color: rgb(230, 225, 192);
        background-color: rgba(2, 4, 23,0.2);
        cursor: pointer;
    }
    .back:hover{
        color: rgba(230,225,192,0.8);
    }
    .info{
        width: 60%;
        height: 30px;
        border-radius: 1em;
        background-color: rgba(247, 211, 184, 0.5);
        color: white;
        font-size: 0.8em;
    }
    .info:hover{
        background-color: rgba(247, 211, 184, 0.7);
    }
    .dhac{
        color:white;
    }
    .regis{
        text-decoration: none;
        color: rgb(187, 187, 238);
    }
    .regis:hover{
    color: rgb(142, 177, 239);
    }
    .submit{
        /*margin-left:25%;*/
        font-size: 0.8em;
        margin-top: 5%;
        cursor: pointer;
        width: 90%;
        height: 30%;
        border-radius: 1em;
        background-color: rgba(251, 191, 145, 0.8);
        margin-bottom: 2%;
    }
    .submit:hover{
        background-color: rgb(189, 244, 246);
    }
    .forgot{
        text-decoration: none;
        clear: both;
        color: white;
        margin-left: 55%;
    }
    .forgot:hover{
        color: aqua;
    }
    </style>
</head>
<body>
<header>

<input type="checkbox" name="toggler" id="toggler">
<label for="toggler" class="fa fa-bars"></label>

<a href="home.php" class="logo"><span>Clown Store</span></a>

        <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
</header>
    
    <?php
        require_once 'helper.php';
        ?>
    <?php 
     if(!empty($_POST)){
            //user click/ submit the page
            //1.1 receive user input from form
            $loginid = $_POST["memberid"];
            $password =($_POST["memberpass"]);
            if(strcmp($loginid,"ST001")==0 && strcmp($password,"Cclcc5030")==0){
                header("Location:../../Admin_Panel/admin_panel/dashboard.php");
            }
            $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $sql ="SELECT * FROM Member WHERE MemberID = '$loginid'";
            $result = $con->query($sql);
            if($result->num_rows ==1){
               $row = $result->fetch_object();
               if(strcmp($password,$row->Password)==0){
                    session_start();
                    $_SESSION["memberID"] = $loginid;

                    // Check for redirect URL
                    if(isset($_SESSION['redirect'])) {
                        $redirect = $_SESSION['redirect'];
                        unset($_SESSION['redirect']);
                        header("Location: $redirect");
                    } else {
                        header("Location: profile.php");
                    }
                    exit();
                }
            }
            else{
                $loginerror = "MemberID not found!";
            }
     }
     
    ?>
    <div style="margin-top:10%;margin-left: 30% " class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Member Login</h1>
    <form method="post" class="formlogin" action="">
        <?php
        if(!empty($loginerror)){
            echo "<p style='color:white'>{$loginerror}</p>";
        }
        ?>
    <label style="color: white;" for="memberid">Member ID :</label>
    <input required class="info" style="width: 60%;height: 20px;text-transform:none;" name="memberid" type="text"><br><br>
    <label style="color: white;" for="memberpass">Password&nbsp;&nbsp; &nbsp;:</label>
    <input required class="info" style="width: 60%;height: 20px;text-transform:none;" name="memberpass" type="password"><br>
    <input type="submit" class="submit" value="Sign in"><br>
    <a class="forgot" href="forgotpass.php">Forgot Password?</a><br><br>
    <span class="dhac">Doesn't have an account?</span> <a class="regis" href="register.php">Register</a>
    </form>
    
    </div>
</body>
</html>