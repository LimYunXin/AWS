<footer>
    <div class="footerContain">
        <div class="socialIcon">
            <a href=""><i class="fa fa-facebook" style="width:5rem;text-align: center;"></i></a>
            <a href=""><i class="fa fa-instagram"></i></a>
            <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-wechat"></i></a>
            <a href=""><i class="fa fa-youtube"></i></a>
        </div>
        
        <div class="footerBottom">
            <p>Copyright &copy; 2024; Desgined By <span class="designer">Clown Store</span></p>
        </div>
    </div>
</footer>

<script>
// Common JavaScript functions can go here
function calculateTotalPrice() {
    var eventName = document.getElementById('event_name').value;
    var ticketType = document.getElementById('ticket_type').value;
    var quantity = document.getElementById('quantity').value;

    if (eventName && ticketType && quantity) {
        fetch('fetch_ticket_price.php?event_name=' + encodeURIComponent(eventName) + '&ticket_type=' + encodeURIComponent(ticketType))
        .then(response => response.json())
        .then(data => {
            var ticketPrice = data.ticket_price;
            var totalPrice = ticketPrice * quantity;
            document.getElementById('total_price').value = totalPrice.toFixed(2);
        })
        .catch(error => console.error('Error fetching ticket price:', error));
    }
}

// Initialize payment method selection
document.addEventListener('DOMContentLoaded', function() {
    if(document.querySelector('.form-check-input')) {
        document.querySelectorAll('.form-check-input').forEach(input => {
            input.addEventListener('change', function() {
                document.querySelectorAll('.payment-method').forEach(method => {
                    method.classList.remove('selected');
                });
                if (this.checked) {
                    this.closest('.payment-method').classList.add('selected');
                }
            });
        });
        
        // Initialize selected payment method
        const checkedInput = document.querySelector('.form-check-input:checked');
        if(checkedInput) {
            checkedInput.closest('.payment-method').classList.add('selected');
        }
    }
});
</script>
</body>
</html>