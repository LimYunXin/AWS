<?php
session_start();
require_once 'databasepart.php';

if (!isset($_SESSION['memberID'])) {
    header("Location: login.php");
    exit();
}

$member_id = $_SESSION['memberID'];

// Fetch all orders for this member
$sql = "SELECT o.bookingid, o.total_amount, o.payment_meth, o.qty, 
               DATE_FORMAT(o.created_at, '%Y-%m-%d') AS order_date,
               (SELECT COUNT(*) FROM orderitems WHERE bookingid = o.bookingid) AS item_count
        FROM `order` o
        WHERE o.member_id = ?
        ORDER BY o.bookingid DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $member_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Your Order History</h2>
        
        <?php if (empty($orders)): ?>
            <div class="alert alert-info">You haven't placed any orders yet.</div>
            <a href="products.php" class="btn btn-primary">Start Shopping</a>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Date</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th>Payment Method</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?php echo $order['bookingid']; ?></td>
                        <td><?php echo $order['order_date']; ?></td>
                        <td><?php echo $order['item_count']; ?> item(s)</td>
                        <td>RM <?php echo number_format($order['total_amount'], 2); ?></td>
                        <td><?php echo ucwords(str_replace('_', ' ', $order['payment_meth'])); ?></td>
                        <td>
                            <a href="order_details.php?order_id=<?php echo $order['bookingid']; ?>" class="btn btn-sm btn-info">View Details</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <a href="products.php" class="btn btn-primary">Back</a>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>