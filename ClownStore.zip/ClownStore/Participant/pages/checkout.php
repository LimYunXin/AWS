<?php
session_start();
require_once 'databasepart.php';

// Redirect to login if not logged in
if (!isset($_SESSION['memberID'])) {
    $_SESSION['redirect'] = 'checkout.php';
    header("Location: login.php");
    exit();
}

if (empty($_SESSION['cart'])) {
    header("Location: products.php");
    exit();
}

// Calculate total
$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['product_price'] * $item['quantity'];
}

// Process checkout
if (isset($_POST['place_order'])) {
    // Insert order header
    $member_id = $_SESSION['memberID'];
    $sql = "INSERT INTO `order` (total_amount, qty, payment_meth, member_id) 
            VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    $qty = array_sum(array_column($_SESSION['cart'], 'quantity'));
    $payment_method = $_POST['payment_method'];
    
    $stmt->bind_param("diss", $total, $qty, $payment_method, $member_id);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();
    
    // Insert order items
    foreach ($_SESSION['cart'] as $item) {
        $product_id = $item['product_id'];
        $quantity = $item['quantity'];
        $unit_price = $item['product_price'];
        $subtotal = $unit_price * $quantity;
        
        $sql = "INSERT INTO orderitems (bookingid, product_id, quantity, unit_price, subtotal) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiidd", $order_id, $product_id, $quantity, $unit_price, $subtotal);
        $stmt->execute();
        $stmt->close();
        
        // Update product stock
        $sql = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $quantity, $product_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Record payment
    $sql = "INSERT INTO payments (payment_method, amount, transaction_id) 
            VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $transaction_id = uniqid();
    $stmt->bind_param("sds", $payment_method, $total, $transaction_id);
    $stmt->execute();
    $stmt->close();
    
    // Clear cart
    unset($_SESSION['cart']);

    // Redirect to confirmation
    header("Location: order_confirmation.php?order_id=$order_id");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
        
        .payment-details {
            display: none;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            margin-top: 15px;
            border: 1px solid #dee2e6;
        }
        
        .payment-details.active {
            display: block;
        }
        
        .payment-method {
            border: 1px solid #dee2e6; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 15px; 
            transition: all 0.3s; 
            cursor: pointer; 
            display: flex; 
            align-items: center;
        }
        
        .payment-method.selected {
            border-color: #ff6b6b !important;
            background-color: rgba(255, 107, 107, 0.1) !important;
        }
        
        header{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: #fff;
            padding: 0.7rem 9%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index:1000;
            box-shadow: 0.5rem 1rem rgba(0, 0, 0, 0.1);
        }

        header .logo{
            font-size: 2rem;
            color: #333;
            font-weight: bolder;
        }

        header .logo span{
            color: peru;
        }

        header .homehead a{
            font-size: 2rem;
            padding: 0 1.5rem;
            color: #666;

        }

        header .homehead a:hover{
            color: peru;
        }
        header .icon {
            padding-top: 2rem;
        }

        header .icon a{
            font-size: 1.5rem;
            color: peachpuff;
            margin-left: 1.5rem;
            float: right;
        }

        header .icon .ccontainer .shopping img{
            max-width: 3.5rem;
            padding: 0;
            margin: 0;
            margin-left: 1rem;
            float: right;
            bottom: 0;
        }

        header .icon a:hover{
            color: firebrick;
        }

        .icon{
            display: flex;
        }

        header #toggler{
            display: none;
        }

        header .fa-bars{
          font-size:3rem;
          color :#333;
          border-radius: 0.5rem;
          padding: 1rem 1rem;
          cursor: pointer;
          border: .1rem solid rgba(0, 0, 0, 0.3);  
          display: none;
        }
        
        footer{
            font-style: italic;
            font-weight: bold;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            background-color: rgba(255,255,255,0.1);
            position: relative;
            top: 100%;
            z-index: 5000;
            left: 5.28%;
            max-width: 94.7%;
        }

        .footerNav ul li{
            list-style-type: none;
        }

        .footerContain{
            width: 100%;
            padding: 70px 30px 20px;
        }

        .socialIcon{
            box-shadow: 0 0.5rem 0.8rem rgba(0,0,0,0.9);
            color: white;
            display: flex;
            justify-content: center;
            background-color: white;
            border-radius: 50px;
        }

        .socialIcon a{
            background-color: white;
            padding: 10px;
            text-decoration: none;

        }

        .socialIcon a i{
            margin: 10px;
            padding: 10px;
            max-width: 100px;
            font-size: 3em;
            color: black;
            opacity: 0.9;
        }

        .socialIcon a:hover{
            color: white;
            transition: 0.5s;
        }

        .socialIcon a:hover i{
            color: white;
            transition: 0.5s;
            background-color: black;
            border-radius: 50%;
        }

        .footerNav{
            margin: 30px 0;
        }

        .footerNav ul{
            display: flex;
            justify-content: center;
        }

        .footerNav ul li a{
            color: white;
            margin: 20px;
            text-decoration: none;
            font-size: 1.5em;
            opacity: 0.4;
            transition: 0.5s;
        }

        .footerNav ul li a:hover{
            opacity: 1;
        }

        .footerBottom{
            padding: 2%;
            text-align: center;
            font-size: 2.5rem;
        }

        .footerBottom p{
            color: rgb(117, 121, 236);
        }

        .designer{
            opacity: 0.7;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: bold;
            margin: 0;
        }
    </style>
</head>
<body>
    <header>
        <input type="checkbox" name="toggler" id="toggler">
        <label for="toggler" class="fa fa-bars"></label>

        <a href="home.php" class="logo"><span>Clown Store</span></a>

        <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            </a>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
    </header>
    
    <div class="container mt-5 pt-5">
        <h2 class="mb-4 fw-bold" style="font-size: 28px; color: #333;">Checkout</h2>
        
        <div class="row g-4">
            <div class="col-lg-8">
                <div style="background-color: white; border-radius: 10px; padding: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
                    <h4 class="mb-4" style="font-size: 20px;">Order Summary</h4>
                    <table class="table" style="font-size: 15px;">
                        <thead style="background-color: #f8f9fa;">
                            <tr>
                                <th style="font-size: 15px; font-weight: 500;">Product</th>
                                <th style="font-size: 15px; font-weight: 500;">Price</th>
                                <th style="font-size: 15px; font-weight: 500;">Quantity</th>
                                <th style="font-size: 15px; font-weight: 500;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($_SESSION['cart'] as $item): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="/ClownStore/Participant/p_asset/images/<?php echo $item['product_pic']; ?>" style="width: 60px; height: 60px; object-fit: contain; border-radius: 5px;" class="me-3">
                                        <?php echo $item['product_name']; ?>
                                    </div>
                                </td>
                                <td>RM <?php echo number_format($item['product_price'], 2); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>RM <?php echo number_format($item['product_price'] * $item['quantity'], 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <tr style="background-color: #f8f9fa;">
                                <td colspan="3" class="text-end" style="font-weight: bold; font-size: 15px;">Total:</td>
                                <td style="font-weight: bold; color: #ff6b6b; font-size: 15px;">RM <?php echo number_format($total, 2); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div style="border: none; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); overflow: hidden;">
                    <div style="background: linear-gradient(135deg, #ff6b6b 0%, #ff5252 100%); color: white; font-weight: 600; padding: 15px 20px; font-size: 18px;">
                        <h5 class="mb-0"><i class="fas fa-credit-card me-2"></i>Payment Method</h5>
                    </div>
                    <div style="padding: 20px; background-color: white;">
                        <form method="post" action="checkout.php">
                            <!-- Payment Method Selection -->
                            <div class="payment-method selected">
                                <input class="form-check-input" type="radio" name="payment_method" id="credit_card" value="credit_card" checked style="margin-right: 15px;">
                                <label class="form-check-label" for="credit_card" style="font-size: 15px;">
                                    <i class="fab fa-cc-visa me-2"></i> Credit Card
                                </label>
                            </div>
                            
                            <div class="payment-method">
                                <input class="form-check-input" type="radio" name="payment_method" id="debit_card" value="debit_card" style="margin-right: 15px;">
                                <label class="form-check-label" for="debit_card" style="font-size: 15px;">
                                    <i class="fas fa-credit-card me-2"></i> Debit Card
                                </label>
                            </div>
                            
                            <div class="payment-method">
                                <input class="form-check-input" type="radio" name="payment_method" id="paypal" value="paypal" style="margin-right: 15px;">
                                <label class="form-check-label" for="paypal" style="font-size: 15px;">
                                    <i class="fab fa-paypal me-2"></i> PayPal
                                </label>
                            </div>
                            
                            <div class="payment-method">
                                <input class="form-check-input" type="radio" name="payment_method" id="tng" value="tng" style="margin-right: 15px;">
                                <label class="form-check-label" for="tng" style="font-size: 15px;">
                                    <i class="fas fa-mobile-alt me-2"></i> Touch 'n Go
                                </label>
                            </div>
                            
                            <div class="payment-method">
                                <input class="form-check-input" type="radio" name="payment_method" id="cash" value="cash" style="margin-right: 15px;">
                                <label class="form-check-label" for="cash" style="font-size: 15px;">
                                    <i class="fas fa-money-bill-wave me-2"></i> Cash Payment
                                </label>
                            </div>
                            
                            <!-- Payment Details Sections -->
                            <div id="credit_card_details" class="payment-details active">
                                <div class="mb-3">
                                    <label for="card_number" class="form-label">Card Number</label>
                                    <input type="text" class="form-control" id="card_number" name="card_number" placeholder="1234 5678 9012 3456">
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="expiry_date" class="form-label">Expiry Date</label>
                                        <input type="text" class="form-control" id="expiry_date" name="expiry_date" placeholder="MM/YY">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="cvv" class="form-label">CVV</label>
                                        <input type="text" class="form-control" id="cvv" name="cvv" placeholder="123">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="card_name" class="form-label">Name on Card</label>
                                    <input type="text" class="form-control" id="card_name" name="card_name" placeholder="John Doe">
                                </div>
                            </div>
                            
                            <div id="debit_card_details" class="payment-details">
                                <div class="mb-3">
                                    <label for="debit_card_number" class="form-label">Card Number</label>
                                    <input type="text" class="form-control" id="debit_card_number" name="debit_card_number" placeholder="1234 5678 9012 3456">
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="debit_expiry_date" class="form-label">Expiry Date</label>
                                        <input type="text" class="form-control" id="debit_expiry_date" name="debit_expiry_date" placeholder="MM/YY">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="debit_cvv" class="form-label">CVV</label>
                                        <input type="text" class="form-control" id="debit_cvv" name="debit_cvv" placeholder="123">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="debit_card_name" class="form-label">Name on Card</label>
                                    <input type="text" class="form-control" id="debit_card_name" name="debit_card_name" placeholder="John Doe">
                                </div>
                            </div>
                            
                            <div id="paypal_details" class="payment-details">
                                <div class="alert alert-info">
                                    You will be redirected to PayPal to complete your payment
                                </div>
                            </div>
                            
                            <div id="tng_details" class="payment-details">
                                <div class="mb-3">
                                    <label for="tng_phone" class="form-label">Phone Number</label>
                                    <input type="text" class="form-control" id="tng_phone" name="tng_phone" placeholder="0123456789">
                                </div>
                                <div class="mb-3">
                                    <label for="tng_pin" class="form-label">TnG PIN</label>
                                    <input type="password" class="form-control" id="tng_pin" name="tng_pin" placeholder="6-digit PIN">
                                </div>
                            </div>
                            
                            <div id="cash_details" class="payment-details">
                                <div class="alert alert-warning">
                                    Please prepare exact amount for cash payment upon delivery
                                </div>
                            </div>
                            
                            <button type="submit" name="place_order" style="background-color: #06d6a0; border-color: #06d6a0; font-weight: 600; letter-spacing: 0.5px; width: 100%; margin-top: 15px; padding: 12px; border-radius: 5px; color: white; font-size: 16px;">
                                <i class="fas fa-check-circle me-2"></i> Place Order
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Function to show payment details based on selected method
        function showPaymentDetails(selectedMethodId) {
            // Hide all payment details sections
            document.querySelectorAll('.payment-details').forEach(detail => {
                detail.classList.remove('active');
            });
            
            // Show the selected payment details
            const detailsId = selectedMethodId + '_details';
            const detailsElement = document.getElementById(detailsId);
            if (detailsElement) {
                detailsElement.classList.add('active');
            }
            
            // Reset all payment method styling
            document.querySelectorAll('.payment-method').forEach(method => {
                method.classList.remove('selected');
            });
            
            // Highlight the selected payment method
            document.getElementById(selectedMethodId).closest('.payment-method').classList.add('selected');
        }

        // Add event listeners to radio buttons
        document.querySelectorAll('input[name="payment_method"]').forEach(input => {
            input.addEventListener('change', function() {
                if (this.checked) {
                    showPaymentDetails(this.id);
                }
            });
        });
        
        // Add click event to the payment method containers
        document.querySelectorAll('.payment-method').forEach(method => {
            method.addEventListener('click', function() {
                // Find the radio input inside this container and select it
                const radio = this.querySelector('input[type="radio"]');
                radio.checked = true;
                
                // Trigger the change event manually
                radio.dispatchEvent(new Event('change'));
            });
        });

        // Initialize with credit card selected
        document.getElementById('credit_card').checked = true;
        showPaymentDetails('credit_card');
    </script>
</body>
</html>