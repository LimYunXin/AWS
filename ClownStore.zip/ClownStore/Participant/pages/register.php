<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../p_asset/js/login.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../p_asset/css/profile.css">
    <link rel="stylesheet" href="../p_asset/css/memberregister.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Member Register</title>
    <style>
        *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    text-transform: capitalize;
    transition: 0.2s linear;
}

html{
    scroll-behavior: smooth;
    scroll-padding-top: 6rem;
    overflow-x: hidden;
}

header{
    font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
    display: flex;
    position: relative;
    top: 0;
    left: 0;
    right: 0;
    background: rgba(255, 255, 255, 0.3);
    padding: 1rem 9%;
    align-items: center;
    justify-content: space-between;
    z-index:1000;
    box-shadow: 0.5rem 1rem rgba(0, 0, 0, 0.1);
}

header .logo{
    font-size: 3rem;
    color: #333;
    font-weight: bolder;
}

header .logo span{
    color: peru;
}

.headertitle{
    font-size: 2rem;
}

header .homehead a{
    font-size: 1.5rem;
    padding: 0 1.5rem;
    color: lightpink;
    
}

header .homehead a:hover{
    color: peru;
}
header .icon {
    padding-top: 2rem;
}

header .icon a{
    font-size: 2rem;
    color: peachpuff;
    margin-left: 1.5rem;
    float: right;
}

header .icon .ccontainer .shopping img{
    max-width: 3.5rem;
    padding: 0;
    margin: 0;
    margin-left: 1rem;
    float: right;
    bottom: 0;
}

header .icon a:hover{
    color: firebrick;
}

.icon{
    display: flex;
}

header #toggler{
    display: none;
}

header .fa-bars{
  font-size:3rem;
  color :#333;
  border-radius: 0.5rem;
  padding: 1.5rem 1.5rem;
  cursor: pointer;
  border: .1rem solid rgba(0, 0, 0, 0.3);  
  display: none;
}



@media (max-width:991px) {
    html{
        font-size: 55%;
    }

    section{
        padding: 2rem;
    } 

    header{
        padding: 2rem;
    }
    
    .home{
        background-position: left;
    }
    
}

@media (max-width:768px){

    header .fa-bars{
        display: block;
    }

    header .homehead{
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: #fff;
        border-top: 0.1rem solid rgba(0, 0, 0, 0.1);
        
    }

    header #toggler:checked ~ .homehead{
        clip-path:polygon(0 0, 100% 0, 100% 0, 0 0);
    }

    header .homehead a{
        margin: 1.5rem;
        padding: 1.5rem;
        background: #fff;
        border: 0.1rem solid rgba(0, 0, 0, 0.1);
        display: block;
    }

    .home .content h3{
        font-size: 5rem;
    }

    .home .content span{
        font-size: 2.5rem;
    }
}

@media (max-width:450px) {
    html{
        font-size: 50%;
    }
    
    .heading{
        font-size: 3rem;
    }
}

body {
    /*background: #f5f5f5;
    margin-top: 20px;*/
    background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url(..//images/sunset2.jpg);
    background-size: cover;
}

.font-weight-bold{
    color: white;
}

.ui-w-80 {
    width : 80px !important;
    height: auto;
}

.btn-default {
    border-color: rgba(14, 18, 23, 0.1);
    background  : rgba(0, 0, 0, 0);
    color       : #4E5155;
}
.btn-default:hover{
background-color: rgba(166, 162, 162, 0.3);
}

label.btn {
    margin-bottom: 0;
}

.btn-outline-primary {
    border-color: #26B4FF;
    background  : transparent;
    color       : #26B4FF;
}

.btn {
    cursor: pointer;
}

.text-light {
    color: #babbbc !important;
}

.btn-facebook {
    border-color: rgba(0, 0, 0, 0);
    background  : #3B5998;
    color       : #fff;
}

.btn-instagram {
    border-color: rgba(0, 0, 0, 0);
    background  : #000;
    color       : #fff;
}

.card {
    background-clip: padding-box;
    box-shadow     : 0 1px 4px rgba(24, 28, 33, 0.012);
}

.row-bordered {
    overflow: hidden;
}

.account-settings-fileinput {
    position  : absolute;
    visibility: hidden;
    width     : 1px;
    height    : 1px;
    opacity   : 0;
}

.account-settings-links .list-group-item.active {
    font-weight: bold !important;
}

html:not(.dark-style) .account-settings-links .list-group-item.active {
    background: transparent !important;
}

.account-settings-multiselect~.select2-container {
    width: 100% !important;
}

.light-style .account-settings-links .list-group-item {
    padding     : 0.85rem 1.5rem;
    border-color: rgba(24, 28, 33, 0.03) !important;
}

.light-style .account-settings-links .list-group-item.active {
    color: #4e5155 !important;
}

.material-style .account-settings-links .list-group-item {
    padding     : 0.85rem 1.5rem;
    border-color: rgba(24, 28, 33, 0.03) !important;
}

.material-style .account-settings-links .list-group-item.active {
    color: #4e5155 !important;
}

.dark-style .account-settings-links .list-group-item {
    padding     : 0.85rem 1.5rem;
    border-color: rgba(255, 255, 255, 0.03) !important;
}

.dark-style .account-settings-links .list-group-item.active {
    color: #fff !important;
}

.light-style .account-settings-links .list-group-item.active {
    color: #4E5155 !important;
}

.light-style .account-settings-links .list-group-item {
    padding     : 0.85rem 1.5rem;
    border-color: rgba(24, 28, 33, 0.03) !important;
}

.caution{
    color: red;
}
.caut{
    font-size: 1.5em;
}

.btn-delete{
    border-color: #e80606 !important;
    background  : transparent !important;
    color       : #0b0b0c !important;
}

.btn-delete:hover{
    background-color: rgba(122, 7, 7, 0.3) !important;
    color: red !important;
}

.btn-logout{
    background-color: rgba(240, 210, 210, 0.8) !important;
    color: #e80606 !important;
}

.btn-logout:hover{
    background-color: rgba(238, 169, 169, 0.8) !important;
    color: #8a0808 !important;
}

button.home{
    border-radius:5px;
    border: orangered solid;
    background-color: rgba(200,0,50,0.6);
    color:white;
}

button.home:hover{
    background-color: rgba(200,0,50,0.8);
    color:aliceblue;
}
        *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    text-transform: capitalize;
    transition: 0.2s linear;
}

html{
    scroll-behavior: smooth;
    scroll-padding-top: 6rem;
    overflow-x: hidden;
}

header{
    font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
    display: flex;
    position: relative;
    top: 0;
    left: 0;
    right: 0;
    background: rgba(255, 255, 255, 0.3);
    padding: 1rem 9%;
    align-items: center;
    justify-content: space-between;
    z-index:1000;
    box-shadow: 0.5rem 1rem rgba(0, 0, 0, 0.1);
}

header .logo{
    font-size: 3rem;
    color: #333;
    font-weight: bolder;
}

header .logo span{
    color: peru;
}

.headertitle{
    font-size: 2rem;
}

header .homehead a{
    font-size: 1.5rem;
    padding: 0 1.5rem;
    color: lightpink;
    
}

header .homehead a:hover{
    color: peru;
}
header .icon {
    padding-top: 2rem;
}

header .icon a{
    font-size: 2rem;
    color: peachpuff;
    margin-left: 1.5rem;
    float: right;
}

header .icon .ccontainer .shopping img{
    max-width: 3.5rem;
    padding: 0;
    margin: 0;
    margin-left: 1rem;
    float: right;
    bottom: 0;
}

header .icon a:hover{
    color: firebrick;
}

.icon{
    display: flex;
}

header #toggler{
    display: none;
}

header .fa-bars{
  font-size:3rem;
  color :#333;
  border-radius: 0.5rem;
  padding: 1.5rem 1.5rem;
  cursor: pointer;
  border: .1rem solid rgba(0, 0, 0, 0.3);  
  display: none;
}



@media (max-width:991px) {
    html{
        font-size: 55%;
    }

    section{
        padding: 2rem;
    } 

    header{
        padding: 2rem;
    }
    
    .home{
        background-position: left;
    }
    
}

@media (max-width:768px){

    header .fa-bars{
        display: block;
    }

    header .homehead{
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: #fff;
        border-top: 0.1rem solid rgba(0, 0, 0, 0.1);
        
    }

    header #toggler:checked ~ .homehead{
        clip-path:polygon(0 0, 100% 0, 100% 0, 0 0);
    }

    header .homehead a{
        margin: 1.5rem;
        padding: 1.5rem;
        background: #fff;
        border: 0.1rem solid rgba(0, 0, 0, 0.1);
        display: block;
    }

    .home .content h3{
        font-size: 5rem;
    }

    .home .content span{
        font-size: 2.5rem;
    }
}

@media (max-width:450px) {
    html{
        font-size: 50%;
    }
    
    .heading{
        font-size: 3rem;
    }
}

body{
    background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url(../images/sunset2.jpg);
    background-size: cover;
}
.formtable{
    margin: 30px 50% 30px 25%;
    border: solid rgb(249, 201, 201) ;
    position: absolute;
    min-width: 600px;
    min-height: 450px;
    font-size: 1.5em;
    }
    
    .title{
        text-align: center;
    text-decoration: none;
    text-align: center;
    font-size: 60px;
    font-family: fantasy;
    color: rgb(253, 242, 242);
    text-shadow: 1px 2px 10px rgb(24, 13, 13);
    }
    
    .formregister{
        position: relative;
        margin-left: 10%;
    }
    .dhac{
        margin-left: 5%;
    }
    .back{
        font-size: larger;
        color: rgb(230, 225, 192);
        background-color: rgba(2, 4, 23,0.2);
        cursor: pointer;
    }
    .back:hover{
        color: rgba(230,225,192,0.8);
    }
.form{
    position: relative;
    margin-left: 10%;
    text-align: left;
}
.info{
    width: 60%;
    height: 30px;
    border-radius: 1em;
    background-color: rgba(247, 211, 184, 0.5);
    color: white;
    font-size: 0.8em;
}
.info:hover{
    background-color: rgba(247, 211, 184, 0.7);
}
.login{
    text-decoration: none;
    color: rgb(187, 187, 238);
}
.login:hover{
color: rgb(142, 177, 239);
}
.submit{
    /*margin-left:25%;*/
    font-size: 0.8em;
    margin-top: 5%;
    cursor: pointer;
    width: 90%;
    height: 30%;
    border-radius: 1em;
    background-color: rgba(251, 191, 145, 0.8);
}
.submit:hover{
    background-color: rgb(189, 244, 246);
}
.dhac{
    color: white;
}
    </style>
</head>
<body>
<header>

<input type="checkbox" name="toggler" id="toggler">
<label for="toggler" class="fa fa-bars"></label>

<a href="home.php" class="logo"><span>Clown Store</span></a>

 <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
</header>
    <?php
        require_once 'helper.php';
        ?>
    <?php 
        if(!empty($_POST)){
            //user click/ submit the page
            //1.1 receive user input from form
            $memID = (trim($_POST["memberid"]));
            $name = trim($_POST["memName"]);
            $password =($_POST["memberpass"]);
            $conpassword =($_POST["memberconpass"]);
            $email =strtolower(trim($_POST["email"]));
            if(isset($_POST["memGender"])){
            $gender = trim($_POST["memGender"]);
            }else{
                $gender ="";
            }
            
            //1.2 check/validate/ verify member detail
           $error["memID"] = validateMemberID($memID);
           $error["name"] =validateMemberName($name);
           $error["gender"] = validateMemberGender($gender);
           $error["password"] = validatePassword($password,$conpassword);
           $error["email"] = validateEmail($email);
           
           //NOTE: when the $error array contains null value
           //array_filter() will remove it
           $error = array_filter($error);
           
           
           if(empty($error)){
               //GOOD, sui no error
               //Step 1: create connection 
         $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            
         //Step 2: sql statement
         $sql = "INSERT INTO Member
                 (MemberID, Password, Gender, Name, Email) 
                 VALUES(?,?,?,?,?)";
         
         $sql2 = "INSERT INTO Account
                 (MemberID, Password, Gender, Name, Email) 
                 VALUES(?,?,?,?,?)";
         //step 3:process sql
         //NOTE: $con->query($sql) <<<<<< when there is NO "?" in sql
         //NOTE: $con->prepare($sql) 
         $stmt = $con->prepare($sql);
         $stmt2 = $con->prepare($sql2);
         //Step 3.1: prepare parameter for sql with "?"
         //NOTE: s - string, d - double, i - integer, b - blob
         $stmt->bind_param("sssss",
                 $memID,$password,$gender,$name,$email);
         $stmt2->bind_param("sssss",
                 $memID,$password,$gender,$name,$email);
         //Step 3.2: execute
         $stmt->execute();
         $stmt2->execute();
         //NOTE:$stmt->affected_rows (this code will only apply to
         // CUD)
         //NOTE: $con->num_rows (how many row of records return) - R
         if($stmt2->affected_rows > 0){
             //insert successfully
             printf("
                 <div class='info'>
                 Member <b>%s</b> sucessfully registered!.
                 [ <a href='register.php'>Back to login</a> ]
                 </div>", $name);
             
         }else{
             //unable to insert
            echo "Database Error, Unable to insert. 
             Please try again!";
         }
         $con->close();
         $stmt->close();  
         $stmt2->close();   
           }
        }
        ?>
        
    <div style="margin-top: 10%;margin-left: 30%" class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Member Register</h1>
    <form method="post" class="formregister" action="">
        <?php if(!empty($error)){
            echo "<ul class='error'>";
               foreach ($error as $value){
                   echo "<li style='color:white'>$value</li>";
               }
               echo "</ul>";
        } ?>
    <table class="form">
    <tr><td><label style="color: white;" for="memberid">Member ID:</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" value="<?php  echo isset($memID)? $memID : ""; ?>" name="memberid" type="text"></td></tr>
    <tr><td><label style="color: white;" for="memberpass">Password :</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" name="memberpass" type="password"></td></tr>
    <tr><td><label style="color: white;" for="memberconpass">Confirm Password :</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" name="memberconpass" type="password"></td></tr>
    <tr><td><label style="color: white;" for="memName">Name :</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" value="<?php echo isset($name)?$name:""; ?>" name="memName" type="text"></td><tr>
    <tr><td><label style="color: white;" for="memGender">Gender :</label></td>
     <td><input type="radio" name="memGender" value="M"  <?php 
                               if(isset($gender) && $gender == "M"){
                                   echo "checked";
                               }else{
                                   echo "";
                               }
                               ?>
                               />
                        <label style="color:white">Male</label>
                        <input type="radio" name="memGender" value="F" <?php 
                               if(isset($gender) && $gender == "F"){
                                   echo "checked";
                               }else{
                                   echo "";
                               }
                               ?>
                               />
                        <label style="color:white">Female</label></td><tr>
    <tr><td ><label style="color: white;" for="email">Email Address :</label></td>
        <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" type="text" name="email"></td><tr>
    <tr><td colspan="2"><input style="width: 90%;height: 30px; border-radius: 1em;" type="submit" class="submit" value="Register"></td></tr>
    <tr><td colspan="2"><span class="dhac">Already have an account?</span> <a class="login" href="login.php">Sign in</a></td></tr>
    </table>
    </form>
    
    </div>
</body>
</html>