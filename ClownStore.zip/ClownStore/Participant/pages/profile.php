<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION["memberID"])) {
    $loginMessage = "Please sign in to view your profile.";
}

// Include any necessary database connection or helper functions here
   require_once 'helper.php';
   $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Assuming you have a function to fetch user data from the database based on their ID
if (isset($_SESSION["memberID"])) {
    $id = $_SESSION["memberID"];
    $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $sql = "SELECT * FROM Member WHERE MemberID = '$id'";
    $result = $con->query($sql);
    
    if($row = $result->fetch_object()){
        $name = $row->Name;
        $password = $row->Password;
        $gender = $row->Gender;
        $email = $row->Email;
        $phone = $row->Phoneno;
        $img = $row->img_path;
        
    }
    $result->free();
}
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if(isset($_POST["changeimg"])){
        $file_name = $_FILES['image']['name'];
       $tempname = $_FILES['image']['tmp_name'];
       if (!empty($file_name)) { // New file has been uploaded
           $folder = 'p_asset/images/' . $file_name;
               $img_path = $file_name;
       } else {
           // No new file uploaded, use old image path
           $img_path = $img;
       }
       $sql1 = "UPDATE Member SET img_path=? WHERE MemberID = ?";
       $stmt1 = $con->prepare($sql1);
       $stmt1->bind_param("ss", $img_path,$id);
       $stmt1->execute();
       $stmt1->close();
       header("Location:{$_SERVER['PHP_SELF']}");
        }
        
    if(isset($_POST["changeinfo"])){
    $editname = $_POST["name"];
    $editgender = $_POST["gender"];
    $editphone = $_POST["phone"];
     //1.2 check/validate/ verify member detail
           $error["name"] =validateMemberName($editname);
           $error["gender"] = validateMemberGender($editgender);
           if($editphone != null){
               if(!preg_match('/^\d{10}$/',$editphone)){
               if(!preg_match('/^\d{11}$/',$editphone)){
                   $error["phone"] = "Contact number must be 10 to 11 digits without dashes.";
               }
               }
           }
           //NOTE: when the $error array contains null value
           //array_filter() will remove it
           $error = array_filter($error);
           if(empty($error)){
           $sql = "UPDATE Member 
                 SET Name = ?, Gender = ?, Phoneno = ?
                 WHERE MemberID = '$id'";
           $sql2 = "UPDATE Account 
                 SET Name = ?, Gender = ?, Phoneno = ?
                 WHERE MemberID = '$id'";
           //step 3:process sql
         $stmt = $con->prepare($sql);
         $stmt2 = $con->prepare($sql2);
          //Step 3.1: prepare parameter for sql with "?"
         //NOTE: s - string, d - double, i - integer, b - blob
         $stmt->bind_param("sss",
                 $editname,$editgender, $editphone);
         $stmt2->bind_param("sss",
                 $editname,$editgender, $editphone);
         //Step 3.2: execute
         $stmt->execute();
         $stmt2->execute();
         $stmt->close();
         $stmt2->close();
         header("Location: {$_SERVER['PHP_SELF']}");
}
else{
               //WITH ERROR, display error msg
               echo "<ul class='error'>";
               foreach ($error as $value){
                   echo "<li style='color:white'>$value</li>";
               }
               echo "</ul>";
               
           }
    }
if(isset($_POST["changepass"])){
    $currentpass = $_POST["currentpass"];
    if(strcmp($currentpass,$password)==0){
    $newpass = $_POST["newpass"];
    $confirmpass = $_POST["conpass"];
    $error["password"] = validatePassword($newpass,$confirmpass);
    $error = array_filter($error);
    
    if(empty($error)){
        $sql3 = "UPDATE Member 
                 SET Password = ?
                 WHERE MemberID = '$id'";
        $sql4 = "UPDATE Account 
                 SET Password = ?
                 WHERE MemberID = '$id'";
        $stmt3 = $con->prepare($sql3);
        $stmt4 = $con->prepare($sql4);
        $stmt3->bind_param("s",
                 $newpass);
         $stmt4->bind_param("s",
                 $newpass);
        $stmt3->execute();
        $stmt4->execute();
        $stmt3->close();
        $stmt4->close();
        header("Location: {$_SERVER['PHP_SELF']}");
    }
    else{
               //WITH ERROR, display error msg
               echo "<ul class='error'>";
               foreach ($error as $value){
                   echo "<li style='color:white'>$value</li>";
               }
               echo "</ul>";
}
    }
    else{
        echo "<li style='color:white'>The current password you entered is not correct!</li>";
    }
    }
  if(isset($_POST["delete"])){
      $deletedate = date("Y-m-d");
      $sql5 = "DELETE FROM Member WHERE MemberID = ?";
      $sql6 = "UPDATE Account SET Deletedate = ? WHERE MemberID =?";
      $stmt5 = $con->prepare($sql5);
      $stmt6 = $con->prepare($sql6);
      $stmt5->bind_param("s",$id);
      $stmt6->bind_param("ss",$deletedate,$id);
      $stmt5->execute();
      $stmt6->execute();
      $stmt5->close();
      $stmt6->close();
      session_destroy();
     header("Location: login.php");
  }
    }   
// Update user profile logic will go here

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="../p_asset/css/profilead.css">
    <link rel="stylesheet" href="../p_asset/css/profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="../p_asset/js/profile.js"></script>
</head>

<body>
    <header>

        <input type="checkbox" name="toggler" id="toggler">
        <label for="toggler" class="fa fa-bars"></label>

        <a href="home.php" class="logo"><span>Clown Store</span></a>

        <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
    </header>
    
    
        <div class="container light-style flex-grow-1 container-p-y">
            <?php 
    if(isset($loginMessage)){
        echo "<h1 style='color:white;margin-left:25%'>{$loginMessage}</h1>";
    }
    ?>
        <?php if (isset($_SESSION["memberID"])) { ?>
            
        <h4 class="font-weight-bold py-3 mb-4">
        Account settings
        </h4>
        <div class="card overflow-hidden">
            <div class="row no-gutters row-bordered row-border-light">
                <div class="col-md-3 pt-0">
                    <div class="list-group list-group-flush account-settings-links">
                        <a class="list-group-item list-group-item-action active" data-toggle="list"
                            href="#account-general">Profile</a>
                        <a class="list-group-item list-group-item-action" data-toggle="list"
                            href="#account-change-password">Change password</a>
                        <!--<a class="list-group-item list-group-item-action" data-toggle="list"
                            href="#account-info">Info</a>
                        <a class="list-group-item list-group-item-action" data-toggle="list"
                            href="#account-social-links">Social links</a>-->
                        <a class="list-group-item list-group-item-action" data-toggle="list"
                            href="#account-delete">Delete Account</a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="account-general">
                            <div class="card-body media align-items-center">
                                <img style="border: rgb(14, 3, 134) solid;" src="../p_asset/images/<?php echo $img?>" alt
                                    class="d-block ui-w-80">
                                <div class="media-body ml-4">
                                    <form method="post" action="" enctype="multipart/form-data">
                                    <label class="btn btn-outline-primary">
                                        Upload new photo
                                        <input type="file" name="image" class="account-settings-fileinput"></label>
                                    &nbsp;
                                    <input type="submit" name="changeimg" class="btn btn-default md-btn-flat" value="Save Photo">
                                    <a href="logout.php" class="btn btn-logout btn-default md-btn-flat">Logout</a></form>
                                    <div class="text-light small mt-1">Allowed JPG, GIF or PNG. Max size of 800K</div>
                                </div>
                            </div>
                            <hr class="border-light m-0">
                            <div class="card-body">
                                <form method="post" action="">
                                <div class="form-group">
                                    <label class="form-label">Name</label>
                                    <input style="text-transform: none;" type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">E-mail</label>
                                    <input style="text-transform: none;" type="text" name="email" disabled class="form-control mb-1" value="<?php echo $email; ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Contact no.</label>
                                    <input type="text" name="phone" class="form-control mb-1" value="<?php echo $phone; ?>">
                                </div>
                                <!--<div class="form-group">
                                    <label class="form-label">Gender</label>
                                    <input type="text" class="form-control" value="<?php echo allGender()[$gender]; ?>">
                                </div>-->
                            <div class="form-group">
    <label class="form-label">Gender</label><br>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="maleCheckbox" value="M" <?php echo ($gender == 'M') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="maleCheckbox">Male</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="femaleCheckbox" value="F" <?php echo ($gender == 'F') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="femaleCheckbox">Female</label>
    </div>
</div>
                            <div class="text-right mt-3">
                                <input type="submit" name="changeinfo" value="Save Changes" class="btn btn-primary">
                            </div>
                            </form>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="account-change-password">
                            <div class="card-body pb-2">
                                <form method="post" action="">
                                <div class="form-group">
                                    <label class="form-label">Current password</label>
                                    <input type="password" name="currentpass" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">New password</label>
                                    <input type="password" name="newpass" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Repeat new password</label>
                                    <input type="password" name="conpass" class="form-control">
                                </div>
                                <div class="text-right mt-3">
                                <input type="submit" name="changepass" value="Save Changes" class="btn btn-primary">
                            </div>
                            </form>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="account-info">
                            <div class="card-body pb-2">
                                <div class="form-group">
                                    <label class="form-label">Bio</label>
                                    <textarea class="form-control"
                                        rows="5">This user doesn't leave anything</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Birthday</label>
                                    <input type="text" class="form-control" value="April 25, 2005">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Country</label>
                                    <select class="custom-select">
                                        <option>Singapore</option>
                                        <option selected>Malaysia</option>
                                        <option>Thailand</option>
                                        <option>Laos</option>
                                        <option>Cambodia</option>
                                    </select>
                                </div>
                            </div>
                            <hr class="border-light m-0">
                            <div class="card-body pb-2">
                                <h6 class="mb-4">Contacts</h6>
                                <div class="form-group">
                                    <label class="form-label">Phone</label>
                                    <input type="text" class="form-control" value="+60 175959052">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email</label>
                                    <input type="text" class="form-control" value="wonghwaiearn@hotmail.com">
                                </div>
                            </div>
                            <div class="text-right mt-3">
                                <button type="button" class="btn btn-primary">Save changes</button>&nbsp;
                                <button type="button" class="btn btn-default">Cancel</button>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="account-social-links">
                            <div class="card-body pb-2">
                                <div class="form-group">
                                    <label class="form-label">Twitter</label>
                                    <input type="text" class="form-control" value="https://twitter.com/hwaiearn">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Facebook</label>
                                    <input type="text" class="form-control" value="https://www.facebook.com/wong.hwaiearn">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Instagram</label>
                                    <input type="text" class="form-control" value="https://www.instagram.com/hwaiearn">
                                </div>
                            </div>
                            <div class="text-right mt-3">
                                <button type="button" class="btn btn-primary">Save changes</button>&nbsp;
                                <button type="button" class="btn btn-default">Cancel</button>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="account-delete">
                            <div class="card-body pb-2">
                                <form method="post" id="accountdlt" name="deleteacc" action="">
                                <div class="form-group">
                                    <h1 class="caution">Caution!</h1>
                                    <div class="caut">Once you delete your account, all of the data in your account will be deleted permanently and this cannot be recover.</div>
                            </div>
                            <div class="text-right mt-3">
                                <input name="delete" onclick="confirmDelete()" type="submit" class="btn btn-delete" value="Delete Account">&nbsp;
            </div>
                                </form>
                        </div>
                        
                    </div>
                </div>
            </div>
            
        </div>
       
    </div>
            <?php } ?>
    </div>
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">

    </script>
    
</body>
</html>
<script>
function logout(){
    window.location.href ="home.php";
}
function tohome(){
    window.location.href ="home.php";
}
function confirmDelete() {
        if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
            // User confirmed, submit the form
            document.getElementById('accountdlt').submit();
        }
    }
</script>