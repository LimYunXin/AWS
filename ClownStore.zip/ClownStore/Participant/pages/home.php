<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>CLown Store</title>
        <link rel="stylesheet" href="../p_asset/css/home.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100..900&display=swap" rel="stylesheet">
    </head>

<body>
    <header>

        <input type="checkbox" name="toggler" id="toggler">
        <label for="toggler" class="fa fa-bars"></label>

        <a href="home.php" class="logo"><span>Clown Store</span></a>

        <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
    </header>
    

    <section class="home" id="home">
        <div class="content">
            <h3>Clown Store</h3>
            <span>The Best Graduation Present</span>
            <p>Buy your graduation present through our website now!</p>
            <a href="products.php" id ="h" class="btn">Order Now</a>
        </div>
    </section>

<section class="about" id="about">
    <h1 class="heading"><span>about</span> us</h1>
    <div class="row">
        <div class="video-container">
            <img src="../p_asset/images/graduationimg.jpg" width="600" height="400" alt="Graduation Image">
            <h3>Best Clown Store</h3>
        </div>

        <div class="content">
            <h3>Clown Store</h3>
            <p>Welcome to Anime society! Our mission is  to provide high-quality, affordable, and fun graduation essentials—from flowers and gowns to keepsake gifts—making your milestone moments even more special. We’re here to help graduates and their loved ones create unforgettable memories with a touch of happiness!</p>
            <p>At Clown Store, buyers can find everything they need to celebrate graduation - from fresh flowers and stylish caps & gowns to cute teddy bears and unique keepsake gifts, all at affordable prices with cheerful service!</p>
        </div>
    </div>
</section>


<section class="contact" id="contact">
    <h1 class="heading"><span>Feed</span>Back</h1>
<?php
    if(!empty($_POST)){
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = $_POST["phone"];
    $message = trim($_POST['message']);

    $db_server = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "assignment";
    $con = new mysqli($db_server, $db_user, $db_pass, $db_name);

   
    $sql = "INSERT INTO feedback (name, email, phone, message) VALUES (?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('ssss', $name, $email, $phone, $message);
    $stmt->execute();

    $stmt->close();
    $con->close();
}
?>
    <div class="row">
    <form action="" method="post">
    <input type="text" name="name" id="name" placeholder="name" class="box" required>
    
    <input type="email" placeholder="email" name="email" id="email" class="box" required>

    <input type="tel" name="phone" id="phone" placeholder="phone" class="box" pattern="[0-9]{3}[0-9]{7}" title="Phone number must be 11 digits and start with 0" required>
    
    <textarea name="message" id="message" cols="30" rows="10" placeholder="message" class="box" required></textarea>
    
    <input type="submit" value="send message" id ="h" class="btn" onclick="return receive();">
</form>


        <div class="image">
            <img src="../p_asset/images/feedback.jpg" alt="my wife">
        </div>

    </div>
</section>

<footer>
    <div class="footerContain">
        <div class="socialIcon">
            <a href=""><i class="fa fa-facebook" style="width:5rem;text-align: center;"></i></a>
            <a href=""><i class="fa fa-instagram"></i></a>
            <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-wechat"></i></a>
            <a href=""><i class="fa fa-youtube"></i></a>
        </div>
        
        <div class="footerBottom">
            <p>Copyright &copy; 2024; Desgined By <span class="designer">Clown Store</span></p>
        </div>
    </div>
</footer>
<script>
function receive() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var phone = document.getElementById('phone').value;

    
    var emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
   
    var phonePattern = /^[0-9]{3}[0-9]{7}$/;


    if(name === "" || email === "" || phone === "") {
        alert("Please fill all required fields.");
        return false;
    }

    if(!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    if(!phonePattern.test(phone)) {
        alert("Please enter a valid phone number (e.g., 0114702903).");
        return false;
    }

    alert("We Have Received Your Feedback. Thank You!");
    return true; 
}


</script>
</body>


<style>
    *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
    outline: none;
    border: none;
    text-decoration: none;
    text-transform: capitalize;
    transition: 0.2s linear;
}

html{
    font-size: 65%;
    scroll-behavior: smooth;
    scroll-padding-top: 6rem;
    overflow-x: hidden;
}
section{
    padding: 2rem 9%;
}

.heading{
    text-align: center;
    font-size: 4rem;
    color: darkgoldenrod;
    padding: 1rem;
    margin: 2rem 0;
    background: rgba(255, 51, 153, .05);
}

.heading span{
    color: salmon;
}

#h{
    display: inline-block;
    margin-top: 1rem;
    border-radius: 5rem;
    background: #333;
    color: #fff;
    padding: 3rem 5rem;
    cursor: pointer;
    font-size: 1.7rem;
}

.btn:hover{
    background: paleturquoise;
}


header{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: #fff;
    padding: 2rem 9%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index:1000;
    box-shadow: 0.5rem 1rem rgba(0, 0, 0, 0.1);
}

header .logo{
    font-size: 3rem;
    color: #333;
    font-weight: bolder;
}

header .logo span{
    color: peru;
}

header .homehead a{
    font-size: 2rem;
    padding: 0 1.5rem;
    color: #666;
    
}

header .homehead a:hover{
    color: peru;
}
header .icon {
    padding-top: 2rem;
}

header .icon a{
    font-size: 2.5rem;
    color: peachpuff;
    margin-left: 1.5rem;
    float: right;
}

header .icon .ccontainer .shopping img{
    max-width: 3.5rem;
    padding: 0;
    margin: 0;
    margin-left: 1rem;
    float: right;
    bottom: 0;
}

header .icon a:hover{
    color: firebrick;
}

.icon{
    display: flex;
}

header #toggler{
    display: none;
}

header .fa-bars{
  font-size:3rem;
  color :#333;
  border-radius: 0.5rem;
  padding: 1.5rem 1.5rem;
  cursor: pointer;
  border: .1rem solid rgba(0, 0, 0, 0.3);  
  display: none;
}



@media (max-width:991px) {
    html{
        font-size: 55%;
    }

    section{
        padding: 2rem;
    } 

    header{
        padding: 2rem;
    }
    
    .home{
        background-position: left;
    }
    
}

@media (max-width:768px){

    header .fa-bars{
        display: block;
    }

    header .homehead{
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: #fff;
        border-top: 0.1rem solid rgba(0, 0, 0, 0.1);
        
    }

    header #toggler:checked ~ .homehead{
        clip-path:polygon(0 0, 100% 0, 100% 0, 0 0);
    }

    header .homehead a{
        margin: 1.5rem;
        padding: 1.5rem;
        background: #fff;
        border: 0.1rem solid rgba(0, 0, 0, 0.1);
        display: block;
    }

    .home .content h3{
        font-size: 5rem;
    }

    .home .content span{
        font-size: 2.5rem;
    }
}

@media (max-width:450px) {
    html{
        font-size: 50%;
    }
    
    .heading{
        font-size: 3rem;
    }
}

.home{
    display: flex;
    align-items: center;
    min-height: 100vh;
    background: url(../images/figure.jpg) no-repeat;
    background-size: cover;
    background-position: center;
}

.home .content{
    max-width: 50rem;
}

.home .content h3{
    font-size: 6rem;
    color:palegoldenrod;
}

.home .content span{
    font-size: 3.5rem;
    color: peachpuff;
    padding: 1rem 0;
    line-height: 1.5;
}

.home .content p{
    font-size:1.8rem;
    color: rgb(251, 247, 251);
    padding: 1rem 0;
    line-height: 1.5;
}

.about .row{
display: flex;
align-items: center;
gap: 2rem;
flex-wrap: wrap;
padding: 2rem 0;
padding-bottom: 3rem;
}

.about .row .video-container{
    flex:1 1 40rem;
    position: relative;
}

.about .row .video-container video{
    width: 100%;
    border: 1.5rem solid #d3b482;
    border-radius: .5rem;
    box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .1);
}

.about .row .video-container h3{
    position: absolute;
    top:20%;
    transform: translateY(-50%);
    font-size: 3rem;
    background: #bbd684;
    padding:1rem 2rem;
    text-align: center;
    mix-blend-mode: screen ;
    
}


.about .row .content{
    flex: 1 1 40rem;
}

.about .row .content h3{
    font-size: 3rem;
    color: rgb(212, 134, 70);
}

.about .row .content p{
    font-size: 1.5rem;
    color: rgb(214, 151, 225);
    padding: 5rem 0;
    padding-top: 1rem;
    line-height: 1.5;
}

.fairs .box-container{
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
}

.fairs .box-container .box{
    flex: 1 1 30rem;
    box-shadow: 0 .5rem 1.5rem rgba(0, 0, 0, .1);
    border-radius: .5rem;
    border:.1rem solid rgba(0, 0, 0, .1);
    position: relative;
}

.fairs .box-container .box .title{
    position: absolute;
    top: 1rem;
    left: 1rem;
    padding: .7rem 1rem;
    font-size: 2rem;
    color: #090909;
    background: rgba(227, 213, 220, 0.05);
    z-index: 1;
    border-radius: .5rem;
}

.fairs .box-container .box .image{
    position: relative;
    text-align: center;
    padding-top: 2rem;
    overflow: hidden;
}

.fairs .box-container .box .image img{
    height: 25rem;
}

.fairs .box-container .box:hover .image img{
    transform: scale(1.1);
}

.fairs .box-container .box .image .icons{
    position: absolute;
    bottom: -7rem;
    left: 0;
    right: 0;
    display: flex;
    
}

.fairs .box-container .box:hover .image .icons{
    bottom: 0;
}

.fairs .box-container .box .image .icons a{
    height: 5rem;
    line-height: 5rem;
    font-size: 2rem;
    width: 50%;
    background: peru;
    color: #fff;
}

.fairs .box-container .box .image .icons .detail-btn{
    border-left: .1rem solid #fff7;
    border-right: .1rem solid #fff7;
    width: 100%;
}

.fairs .box-container .box .image .icons a:hover{
    background: #e192ce;
}

.fairs .box-container .box .content{
    padding: 2rem;
    text-align: center;
}

.fairs .box-container .box .content h3{
    font-size: 2.5rem;
    color: #333;
}

.fairs .box-container .box .content .price{
    font-size: 2.5rem;
    color: rgb(20, 20, 19);
    font-weight: bolder;
    padding-top: 1rem;
}

.fairs .box-container .box .content .price span{
    font-size: 2.5rem;
    color: peru;
}

.contact .row{
    display: flex;
    flex-wrap: wrap-reverse;
    gap: 1.5rem;
    align-items: center;
}

.contact .row form{
    flex: 1 1 40rem;
    padding: 2rem 2.5rem;
    box-shadow: 0 .5rem 1.5rem rgba(0, 0, 0, .1);
    border: 1rem solid rgba(0, 0, 0, .1);
    background: #fff;
    border-radius: .5rem;
}

.contact .row .image{
    flex: 1 1 40rem;
}

.contact .row .image img{
    width: 100%;
}

.contact .row form .box{
    padding: 1rem;
    font-size: 1.7rem;
    color: #333;
    text-transform: none;
    border: .5rem;
    margin: .7rem 0;
    width: 100%;
}

.contact .row form .box:focus{
    border-color: peru;
}

.contact .row form textarea{
    height: 15rem;
    resize: none;
}

footer{
    font-style: italic;
    font-weight: bold;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    background-color: rgba(255,255,255,0.1);
    position: relative;
    top: 100%;
    z-index: 5000;
    left: 5.28%;
    max-width: 94.7%;
}

.footerNav ul li{
    list-style-type: none;
}

.footerContain{
    width: 100%;
    padding: 70px 30px 20px;
}

.socialIcon{
    box-shadow: 0 0.5rem 0.8rem rgba(0,0,0,0.9);
    color: white;
    display: flex;
    justify-content: center;
    background-color: white;
    border-radius: 50px;
}

.socialIcon a{
    background-color: white;
    padding: 10px;
    text-decoration: none;
    
}

.socialIcon a i{
    margin: 10px;
    padding: 10px;
    max-width: 100px;
    font-size: 3em;
    color: black;
    opacity: 0.9;
}

.socialIcon a:hover{
    color: white;
    transition: 0.5s;
}

.socialIcon a:hover i{
    color: white;
    transition: 0.5s;
    background-color: black;
    border-radius: 50%;
}

.footerNav{
    margin: 30px 0;
}

.footerNav ul{
    display: flex;
    justify-content: center;
}

.footerNav ul li a{
    color: white;
    margin: 20px;
    text-decoration: none;
    font-size: 1.5em;
    opacity: 0.4;
    transition: 0.5s;
}

.footerNav ul li a:hover{
    opacity: 1;
}

.footerBottom{
    padding: 2%;
    text-align: center;
    font-size: 2.5rem;
}

.footerBottom p{
    color: rgb(117, 121, 236);
}

.designer{
    opacity: 0.7;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: bold;
    margin: 0;
}

.cart-count {
    background: #ffb02f;
    color: white;
    border-radius: 50%;
    padding: 2px 6px;
    font-size: 12px;
    position: relative;
    top: -10px;
    right: 5px;
}
</style>
</html>