function deleteacc(){
    window.location.href ="home.php";
}